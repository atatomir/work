#include<cstdio>
#include<utility>
#include<vector>
#include<algorithm>
using namespace std;
FILE *FOUT,*FOK;
vector< pair < pair<int,int> , pair<int,int> > > QOK,QOUT;
int NOK,NOUT,i,a,b,c,d;
void MSG(const char *msg,int pc)
{
    printf("%d %s",pc,msg);
    exit(0);
}
int main()
{
    FOK=fopen("drep2.ok","r");
    fscanf(FOK,"%d",&NOK);
    for(i=1;i<=NOK;i++)
    {
        fscanf(FOK,"%d%d%d%d",&a,&b,&c,&d);
        QOK.push_back(make_pair(make_pair(a,b),make_pair(c,d)));
    }
    fclose(FOK);
    FOUT=fopen("drep2.out","r");
    if(!FOUT)MSG("Fisier de iesire lipsa",0);
    if(fscanf(FOUT,"%d",&NOUT)==-1)MSG("Fisier de iesire vid",0);
    if(NOUT!=NOK)MSG("Raspuns gresit",0);
    for(i=1;i<=NOUT;i++)
    {
        if(fscanf(FOUT,"%d%d%d%d",&a,&b,&c,&d)!=4)MSG("Al raspuns doilea gresit",2);
        QOUT.push_back(make_pair(make_pair(a,b),make_pair(c,d)));
    }
    sort(QOK.begin(),QOK.end());
    sort(QOUT.begin(),QOUT.end());
    if(QOK==QOUT)MSG("CORECT!!!",10);
    MSG("Al raspuns doilea gresit",2);
    return 0;
}
